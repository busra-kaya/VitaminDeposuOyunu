﻿
namespace VitaminDeposuOyunu
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MeyvelerPanel = new System.Windows.Forms.Panel();
            this.MeyvelerLabelText = new System.Windows.Forms.Label();
            this.ResimlerPictureBox = new System.Windows.Forms.PictureBox();
            this.KatiMeyvePanel = new System.Windows.Forms.Panel();
            this.KatiMeyveSikacagiList = new System.Windows.Forms.ListBox();
            this.KatiMeyveSikacagiBtn = new System.Windows.Forms.Button();
            this.SiviMeyvePanel = new System.Windows.Forms.Panel();
            this.SiviMeyveSikacagiList = new System.Windows.Forms.ListBox();
            this.SiviMeyveSikacagiBtn = new System.Windows.Forms.Button();
            this.HesaplamaPanel = new System.Windows.Forms.Panel();
            this.CVitaminiGramLabel = new System.Windows.Forms.Label();
            this.CVitaminiGramLabelText = new System.Windows.Forms.Label();
            this.AVitaminiGramLabel = new System.Windows.Forms.Label();
            this.AVitaminiGramLabelText = new System.Windows.Forms.Label();
            this.MeyvePuresiGramLabel = new System.Windows.Forms.Label();
            this.MeyveSuyuGramLabelText = new System.Windows.Forms.Label();
            this.MeyvePuresiGramLabelText = new System.Windows.Forms.Label();
            this.MeyveSuyuGramLabel = new System.Windows.Forms.Label();
            this.GirisPanel = new System.Windows.Forms.Panel();
            this.OyunuSonlandirBtn = new System.Windows.Forms.Button();
            this.KalanSureLabel = new System.Windows.Forms.Label();
            this.KalanSureLabelText = new System.Windows.Forms.Label();
            this.YeniOyunBtn = new System.Windows.Forms.Button();
            this.Zamanlayıcı = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CVitaminiList = new System.Windows.Forms.ListBox();
            this.AVitaminiList = new System.Windows.Forms.ListBox();
            this.MeyveSuyuList = new System.Windows.Forms.ListBox();
            this.MeyvePuresiList = new System.Windows.Forms.ListBox();
            this.MeyvelerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ResimlerPictureBox)).BeginInit();
            this.KatiMeyvePanel.SuspendLayout();
            this.SiviMeyvePanel.SuspendLayout();
            this.HesaplamaPanel.SuspendLayout();
            this.GirisPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MeyvelerPanel
            // 
            this.MeyvelerPanel.BackColor = System.Drawing.Color.PaleVioletRed;
            this.MeyvelerPanel.Controls.Add(this.MeyvelerLabelText);
            this.MeyvelerPanel.Controls.Add(this.ResimlerPictureBox);
            this.MeyvelerPanel.Location = new System.Drawing.Point(31, 38);
            this.MeyvelerPanel.Name = "MeyvelerPanel";
            this.MeyvelerPanel.Size = new System.Drawing.Size(321, 317);
            this.MeyvelerPanel.TabIndex = 0;
            // 
            // MeyvelerLabelText
            // 
            this.MeyvelerLabelText.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.MeyvelerLabelText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MeyvelerLabelText.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MeyvelerLabelText.Location = new System.Drawing.Point(26, 22);
            this.MeyvelerLabelText.Name = "MeyvelerLabelText";
            this.MeyvelerLabelText.Size = new System.Drawing.Size(270, 31);
            this.MeyvelerLabelText.TabIndex = 5;
            this.MeyvelerLabelText.Text = "MEYVELER";
            this.MeyvelerLabelText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ResimlerPictureBox
            // 
            this.ResimlerPictureBox.BackColor = System.Drawing.Color.White;
            this.ResimlerPictureBox.Location = new System.Drawing.Point(26, 62);
            this.ResimlerPictureBox.Name = "ResimlerPictureBox";
            this.ResimlerPictureBox.Size = new System.Drawing.Size(270, 224);
            this.ResimlerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ResimlerPictureBox.TabIndex = 0;
            this.ResimlerPictureBox.TabStop = false;
            // 
            // KatiMeyvePanel
            // 
            this.KatiMeyvePanel.BackColor = System.Drawing.Color.PaleVioletRed;
            this.KatiMeyvePanel.Controls.Add(this.KatiMeyveSikacagiList);
            this.KatiMeyvePanel.Controls.Add(this.KatiMeyveSikacagiBtn);
            this.KatiMeyvePanel.Location = new System.Drawing.Point(382, 38);
            this.KatiMeyvePanel.Name = "KatiMeyvePanel";
            this.KatiMeyvePanel.Size = new System.Drawing.Size(452, 317);
            this.KatiMeyvePanel.TabIndex = 1;
            // 
            // KatiMeyveSikacagiList
            // 
            this.KatiMeyveSikacagiList.BackColor = System.Drawing.Color.White;
            this.KatiMeyveSikacagiList.FormattingEnabled = true;
            this.KatiMeyveSikacagiList.ItemHeight = 20;
            this.KatiMeyveSikacagiList.Location = new System.Drawing.Point(26, 62);
            this.KatiMeyveSikacagiList.Name = "KatiMeyveSikacagiList";
            this.KatiMeyveSikacagiList.Size = new System.Drawing.Size(391, 224);
            this.KatiMeyveSikacagiList.TabIndex = 1;
            // 
            // KatiMeyveSikacagiBtn
            // 
            this.KatiMeyveSikacagiBtn.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.KatiMeyveSikacagiBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.KatiMeyveSikacagiBtn.Location = new System.Drawing.Point(26, 26);
            this.KatiMeyveSikacagiBtn.Name = "KatiMeyveSikacagiBtn";
            this.KatiMeyveSikacagiBtn.Size = new System.Drawing.Size(391, 34);
            this.KatiMeyveSikacagiBtn.TabIndex = 0;
            this.KatiMeyveSikacagiBtn.Text = "KATI MEYVE SIKACAĞI";
            this.KatiMeyveSikacagiBtn.UseVisualStyleBackColor = false;
            this.KatiMeyveSikacagiBtn.Click += new System.EventHandler(this.KatiMeyveSikacagiBtn_Click);
            // 
            // SiviMeyvePanel
            // 
            this.SiviMeyvePanel.BackColor = System.Drawing.Color.PaleVioletRed;
            this.SiviMeyvePanel.Controls.Add(this.SiviMeyveSikacagiList);
            this.SiviMeyvePanel.Controls.Add(this.SiviMeyveSikacagiBtn);
            this.SiviMeyvePanel.Location = new System.Drawing.Point(832, 38);
            this.SiviMeyvePanel.Name = "SiviMeyvePanel";
            this.SiviMeyvePanel.Size = new System.Drawing.Size(405, 317);
            this.SiviMeyvePanel.TabIndex = 2;
            // 
            // SiviMeyveSikacagiList
            // 
            this.SiviMeyveSikacagiList.BackColor = System.Drawing.Color.White;
            this.SiviMeyveSikacagiList.FormattingEnabled = true;
            this.SiviMeyveSikacagiList.ItemHeight = 20;
            this.SiviMeyveSikacagiList.Location = new System.Drawing.Point(0, 62);
            this.SiviMeyveSikacagiList.Name = "SiviMeyveSikacagiList";
            this.SiviMeyveSikacagiList.Size = new System.Drawing.Size(373, 224);
            this.SiviMeyveSikacagiList.TabIndex = 1;
            // 
            // SiviMeyveSikacagiBtn
            // 
            this.SiviMeyveSikacagiBtn.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.SiviMeyveSikacagiBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SiviMeyveSikacagiBtn.Location = new System.Drawing.Point(0, 26);
            this.SiviMeyveSikacagiBtn.Name = "SiviMeyveSikacagiBtn";
            this.SiviMeyveSikacagiBtn.Size = new System.Drawing.Size(373, 34);
            this.SiviMeyveSikacagiBtn.TabIndex = 0;
            this.SiviMeyveSikacagiBtn.Text = "SIVI MEYVE SIKACAĞI";
            this.SiviMeyveSikacagiBtn.UseVisualStyleBackColor = false;
            this.SiviMeyveSikacagiBtn.Click += new System.EventHandler(this.SiviMeyveSikacagiBtn_Click);
            // 
            // HesaplamaPanel
            // 
            this.HesaplamaPanel.BackColor = System.Drawing.Color.PaleVioletRed;
            this.HesaplamaPanel.Controls.Add(this.CVitaminiGramLabel);
            this.HesaplamaPanel.Controls.Add(this.CVitaminiGramLabelText);
            this.HesaplamaPanel.Controls.Add(this.AVitaminiGramLabel);
            this.HesaplamaPanel.Controls.Add(this.AVitaminiGramLabelText);
            this.HesaplamaPanel.Controls.Add(this.MeyvePuresiGramLabel);
            this.HesaplamaPanel.Controls.Add(this.MeyveSuyuGramLabelText);
            this.HesaplamaPanel.Controls.Add(this.MeyvePuresiGramLabelText);
            this.HesaplamaPanel.Controls.Add(this.MeyveSuyuGramLabel);
            this.HesaplamaPanel.Location = new System.Drawing.Point(382, 645);
            this.HesaplamaPanel.Name = "HesaplamaPanel";
            this.HesaplamaPanel.Size = new System.Drawing.Size(855, 148);
            this.HesaplamaPanel.TabIndex = 3;
            // 
            // CVitaminiGramLabel
            // 
            this.CVitaminiGramLabel.BackColor = System.Drawing.Color.White;
            this.CVitaminiGramLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CVitaminiGramLabel.Location = new System.Drawing.Point(228, 80);
            this.CVitaminiGramLabel.Name = "CVitaminiGramLabel";
            this.CVitaminiGramLabel.Size = new System.Drawing.Size(189, 45);
            this.CVitaminiGramLabel.TabIndex = 7;
            this.CVitaminiGramLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CVitaminiGramLabelText
            // 
            this.CVitaminiGramLabelText.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.CVitaminiGramLabelText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CVitaminiGramLabelText.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CVitaminiGramLabelText.Location = new System.Drawing.Point(28, 80);
            this.CVitaminiGramLabelText.Name = "CVitaminiGramLabelText";
            this.CVitaminiGramLabelText.Size = new System.Drawing.Size(200, 45);
            this.CVitaminiGramLabelText.TabIndex = 6;
            this.CVitaminiGramLabelText.Text = "TOPLAM C-VİTAMİNİ";
            this.CVitaminiGramLabelText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AVitaminiGramLabel
            // 
            this.AVitaminiGramLabel.BackColor = System.Drawing.Color.White;
            this.AVitaminiGramLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AVitaminiGramLabel.Location = new System.Drawing.Point(227, 24);
            this.AVitaminiGramLabel.Name = "AVitaminiGramLabel";
            this.AVitaminiGramLabel.Size = new System.Drawing.Size(190, 45);
            this.AVitaminiGramLabel.TabIndex = 5;
            this.AVitaminiGramLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AVitaminiGramLabelText
            // 
            this.AVitaminiGramLabelText.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.AVitaminiGramLabelText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AVitaminiGramLabelText.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AVitaminiGramLabelText.Location = new System.Drawing.Point(27, 24);
            this.AVitaminiGramLabelText.Name = "AVitaminiGramLabelText";
            this.AVitaminiGramLabelText.Size = new System.Drawing.Size(200, 45);
            this.AVitaminiGramLabelText.TabIndex = 4;
            this.AVitaminiGramLabelText.Text = "TOPLAM A-VİTAMİNİ";
            this.AVitaminiGramLabelText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MeyvePuresiGramLabel
            // 
            this.MeyvePuresiGramLabel.BackColor = System.Drawing.Color.White;
            this.MeyvePuresiGramLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MeyvePuresiGramLabel.Location = new System.Drawing.Point(650, 80);
            this.MeyvePuresiGramLabel.Name = "MeyvePuresiGramLabel";
            this.MeyvePuresiGramLabel.Size = new System.Drawing.Size(184, 45);
            this.MeyvePuresiGramLabel.TabIndex = 3;
            this.MeyvePuresiGramLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MeyveSuyuGramLabelText
            // 
            this.MeyveSuyuGramLabelText.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.MeyveSuyuGramLabelText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MeyveSuyuGramLabelText.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MeyveSuyuGramLabelText.Location = new System.Drawing.Point(450, 24);
            this.MeyveSuyuGramLabelText.Name = "MeyveSuyuGramLabelText";
            this.MeyveSuyuGramLabelText.Size = new System.Drawing.Size(200, 45);
            this.MeyveSuyuGramLabelText.TabIndex = 0;
            this.MeyveSuyuGramLabelText.Text = "MEYVE SUYU GRAMI";
            this.MeyveSuyuGramLabelText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MeyvePuresiGramLabelText
            // 
            this.MeyvePuresiGramLabelText.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.MeyvePuresiGramLabelText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MeyvePuresiGramLabelText.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MeyvePuresiGramLabelText.Location = new System.Drawing.Point(450, 80);
            this.MeyvePuresiGramLabelText.Name = "MeyvePuresiGramLabelText";
            this.MeyvePuresiGramLabelText.Size = new System.Drawing.Size(200, 45);
            this.MeyvePuresiGramLabelText.TabIndex = 2;
            this.MeyvePuresiGramLabelText.Text = "MEYVE PÜRESİ GRAMI";
            this.MeyvePuresiGramLabelText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MeyveSuyuGramLabel
            // 
            this.MeyveSuyuGramLabel.BackColor = System.Drawing.Color.White;
            this.MeyveSuyuGramLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MeyveSuyuGramLabel.Location = new System.Drawing.Point(645, 24);
            this.MeyveSuyuGramLabel.Name = "MeyveSuyuGramLabel";
            this.MeyveSuyuGramLabel.Size = new System.Drawing.Size(189, 45);
            this.MeyveSuyuGramLabel.TabIndex = 1;
            this.MeyveSuyuGramLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GirisPanel
            // 
            this.GirisPanel.BackColor = System.Drawing.Color.PaleVioletRed;
            this.GirisPanel.Controls.Add(this.OyunuSonlandirBtn);
            this.GirisPanel.Controls.Add(this.KalanSureLabel);
            this.GirisPanel.Controls.Add(this.KalanSureLabelText);
            this.GirisPanel.Controls.Add(this.YeniOyunBtn);
            this.GirisPanel.Location = new System.Drawing.Point(31, 381);
            this.GirisPanel.Name = "GirisPanel";
            this.GirisPanel.Size = new System.Drawing.Size(321, 412);
            this.GirisPanel.TabIndex = 4;
            // 
            // OyunuSonlandirBtn
            // 
            this.OyunuSonlandirBtn.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.OyunuSonlandirBtn.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OyunuSonlandirBtn.Location = new System.Drawing.Point(26, 270);
            this.OyunuSonlandirBtn.Name = "OyunuSonlandirBtn";
            this.OyunuSonlandirBtn.Size = new System.Drawing.Size(270, 74);
            this.OyunuSonlandirBtn.TabIndex = 3;
            this.OyunuSonlandirBtn.Text = "OYUNU SONLANDIR";
            this.OyunuSonlandirBtn.UseVisualStyleBackColor = false;
            this.OyunuSonlandirBtn.Click += new System.EventHandler(this.OyunuSonlandirBtn_Click);
            // 
            // KalanSureLabel
            // 
            this.KalanSureLabel.BackColor = System.Drawing.Color.White;
            this.KalanSureLabel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.KalanSureLabel.Location = new System.Drawing.Point(26, 207);
            this.KalanSureLabel.Name = "KalanSureLabel";
            this.KalanSureLabel.Size = new System.Drawing.Size(270, 47);
            this.KalanSureLabel.TabIndex = 2;
            this.KalanSureLabel.Text = "60";
            this.KalanSureLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // KalanSureLabelText
            // 
            this.KalanSureLabelText.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.KalanSureLabelText.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.KalanSureLabelText.Location = new System.Drawing.Point(26, 159);
            this.KalanSureLabelText.Name = "KalanSureLabelText";
            this.KalanSureLabelText.Size = new System.Drawing.Size(270, 48);
            this.KalanSureLabelText.TabIndex = 1;
            this.KalanSureLabelText.Text = "KALAN SÜRE";
            this.KalanSureLabelText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // YeniOyunBtn
            // 
            this.YeniOyunBtn.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.YeniOyunBtn.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.YeniOyunBtn.Location = new System.Drawing.Point(26, 66);
            this.YeniOyunBtn.Name = "YeniOyunBtn";
            this.YeniOyunBtn.Size = new System.Drawing.Size(270, 74);
            this.YeniOyunBtn.TabIndex = 0;
            this.YeniOyunBtn.Text = "YENİ OYUN";
            this.YeniOyunBtn.UseVisualStyleBackColor = false;
            this.YeniOyunBtn.Click += new System.EventHandler(this.YeniOyunBtn_Click);
            // 
            // Zamanlayıcı
            // 
            this.Zamanlayıcı.Tick += new System.EventHandler(this.Zamanlayıcı_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PaleVioletRed;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.CVitaminiList);
            this.panel1.Controls.Add(this.AVitaminiList);
            this.panel1.Controls.Add(this.MeyveSuyuList);
            this.panel1.Controls.Add(this.MeyvePuresiList);
            this.panel1.Location = new System.Drawing.Point(382, 381);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(855, 246);
            this.panel1.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(645, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(189, 34);
            this.label4.TabIndex = 7;
            this.label4.Text = "C VİTAMİNİ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(450, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 34);
            this.label3.TabIndex = 6;
            this.label3.Text = "A VİTAMİNİ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(227, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 34);
            this.label2.TabIndex = 5;
            this.label2.Text = "MEYVE SUYU";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(26, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 34);
            this.label1.TabIndex = 4;
            this.label1.Text = "MEYVE PÜRESİ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CVitaminiList
            // 
            this.CVitaminiList.FormattingEnabled = true;
            this.CVitaminiList.ItemHeight = 20;
            this.CVitaminiList.Location = new System.Drawing.Point(645, 45);
            this.CVitaminiList.Name = "CVitaminiList";
            this.CVitaminiList.Size = new System.Drawing.Size(189, 184);
            this.CVitaminiList.TabIndex = 3;
            // 
            // AVitaminiList
            // 
            this.AVitaminiList.FormattingEnabled = true;
            this.AVitaminiList.ItemHeight = 20;
            this.AVitaminiList.Location = new System.Drawing.Point(450, 45);
            this.AVitaminiList.Name = "AVitaminiList";
            this.AVitaminiList.Size = new System.Drawing.Size(189, 184);
            this.AVitaminiList.TabIndex = 2;
            // 
            // MeyveSuyuList
            // 
            this.MeyveSuyuList.FormattingEnabled = true;
            this.MeyveSuyuList.ItemHeight = 20;
            this.MeyveSuyuList.Location = new System.Drawing.Point(227, 45);
            this.MeyveSuyuList.Name = "MeyveSuyuList";
            this.MeyveSuyuList.Size = new System.Drawing.Size(190, 184);
            this.MeyveSuyuList.TabIndex = 1;
            // 
            // MeyvePuresiList
            // 
            this.MeyvePuresiList.FormattingEnabled = true;
            this.MeyvePuresiList.ItemHeight = 20;
            this.MeyvePuresiList.Location = new System.Drawing.Point(26, 45);
            this.MeyvePuresiList.Name = "MeyvePuresiList";
            this.MeyvePuresiList.Size = new System.Drawing.Size(195, 184);
            this.MeyvePuresiList.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1343, 826);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.GirisPanel);
            this.Controls.Add(this.SiviMeyvePanel);
            this.Controls.Add(this.HesaplamaPanel);
            this.Controls.Add(this.KatiMeyvePanel);
            this.Controls.Add(this.MeyvelerPanel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MeyvelerPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ResimlerPictureBox)).EndInit();
            this.KatiMeyvePanel.ResumeLayout(false);
            this.SiviMeyvePanel.ResumeLayout(false);
            this.HesaplamaPanel.ResumeLayout(false);
            this.GirisPanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel MeyvelerPanel;
        private System.Windows.Forms.PictureBox ResimlerPictureBox;
        private System.Windows.Forms.Panel KatiMeyvePanel;
        private System.Windows.Forms.ListBox KatiMeyveSikacagiList;
        private System.Windows.Forms.Button KatiMeyveSikacagiBtn;
        private System.Windows.Forms.Panel SiviMeyvePanel;
        private System.Windows.Forms.ListBox SiviMeyveSikacagiList;
        private System.Windows.Forms.Button SiviMeyveSikacagiBtn;
        private System.Windows.Forms.Panel HesaplamaPanel;
        private System.Windows.Forms.Label CVitaminiGramLabel;
        private System.Windows.Forms.Label CVitaminiGramLabelText;
        private System.Windows.Forms.Label AVitaminiGramLabel;
        private System.Windows.Forms.Label AVitaminiGramLabelText;
        private System.Windows.Forms.Label MeyvePuresiGramLabel;
        private System.Windows.Forms.Label MeyvePuresiGramLabelText;
        private System.Windows.Forms.Label MeyveSuyuGramLabel;
        private System.Windows.Forms.Label MeyveSuyuGramLabelText;
        private System.Windows.Forms.Panel GirisPanel;
        private System.Windows.Forms.Label KalanSureLabel;
        private System.Windows.Forms.Label KalanSureLabelText;
        private System.Windows.Forms.Button YeniOyunBtn;
        private System.Windows.Forms.Label MeyvelerLabelText;
        private System.Windows.Forms.Timer Zamanlayıcı;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox CVitaminiList;
        private System.Windows.Forms.ListBox AVitaminiList;
        private System.Windows.Forms.ListBox MeyveSuyuList;
        private System.Windows.Forms.ListBox MeyvePuresiList;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button OyunuSonlandirBtn;
    }
}

