﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VitaminDeposuOyunu
{
        public interface IMeyveler
        {
            public int AVitamini { get; set; }
            public int CVitamini { get; set; }
            public System.Drawing.Image Image { get; set; }
        }
    
}
